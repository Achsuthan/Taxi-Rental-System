<?php  include_once("scripts/global.php");



if (isset($_POST['user'])) {
	$user=$_POST['user'];
	$pass=$_POST['pass'];
	$remember=$_POST['remember'];
	
	//error handling
	if(!$user || !$pass){
		
		echo "Please insert both fields";
		
		
	}
	else{
		//secure data
		$user=mysql_real_escape_string($user);
		$pass=sha1($pass);
		$query=mysql_query("SELECT * FROM members WHERE username='$user'  and password='$pass' LIMIT 1") or die("Could not check member");
		$count_query= mysql_num_rows($query);
		
		if ($count_query == 0) {
			echo "the Information you entered was incorrect";
			
		}
		else {
			//start sessions
			
			$_SESSION['pass']=$pass;
			while ($row=mysql_fetch_array($query)) {
				
				$username=$row['username'];
				
				
			}
			$_SESSION['username']=$username;
			
			if($remember=='yes'){
				//create cookies
				setcookie("username_cookie",$username,time()+60*60*24*100,"/");
				setcookie("pass_cookie",$pass,time()+60*60*24*100,"/");
				
			}
			header("location:home.php");
		}
		
	}
	
	
}

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		
	
		
		
		<title>login</title>
		
		<style>
			
body{
	margin: 0;
	padding: 0;
	background: #fff;

	color: #fff;
	font-family: Arial;
	font-size: 12px;
}
.body{
	position: absolute;
	top: -20px;
	left: -20px;
	right: -40px;
	bottom: -40px;
	width: auto;
	height: auto;
	background-image: url(a.jpg);
	background-size: cover;
}

.login{
	position: absolute;
	top: calc(50% - 75px);
	left: calc(50% - 50px);
	height: 150px;
	width: 350px;
	padding: 10px;
	z-index: 2;
}

.login input[type=text]{
	width: 250px;
	height: 30px;
	background: transparent;
	border: 1px solid rgba(255,255,255,0.6);
	border-radius: 2px;
	color: #fff;
	font-family: 'Exo', sans-serif;
	font-size: 16px;
	font-weight: 400;
	padding: 4px;
}

.login input[type=password]{
	width: 250px;
	height: 30px;
	background: transparent;
	border: 1px solid rgba(255,255,255,0.6);
	border-radius: 2px;
	color: #fff;
	font-family: 'Exo', sans-serif;
	font-size: 16px;
	font-weight: 400;
	padding: 4px;
	margin-top: 10px;
}

.login input[type=button]{
	width: 260px;
	height: 35px;
	background: #fff;
	border: 1px solid #fff;
	cursor: pointer;
	border-radius: 2px;
	color: #a18d6c;
	font-family: 'Exo', sans-serif;
	font-size: 16px;
	font-weight: 400;
	padding: 6px;
	margin-top: 10px;
}

.login input[type=button]:hover{
	opacity: 0.8;
}


		</style>
		
	</head>
          
     	 <body>
				<h1><span>YAMU</span> TAXI</h1>
				<form action="Login.php" method="post">

  <div class="body"></div>
		
			<div>Login<span>Page</span></div>
		</div>
		<br>
		<div class="login">
				<input type="text" placeholder="USERNAME" name="user"><br>
				<input type="password" placeholder="PASSWORD" name="password"><br>
				<input type="checkbox" name="remember" value="yes" checked="checked"/>Remember me?<br />
				<input type="button" value="Login">
		</div>
			
	
	</body>
	<footer>
				<p>
					&copy; Copyright  by Aravinthan
				</p>
			</footer>
</html>
